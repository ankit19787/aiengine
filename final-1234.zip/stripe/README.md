
Stripe Full Billing

Flow:
- Workspace -> Customer
- Customer -> Subscription
- Usage middleware -> chargeUsage()

Enforce limits BEFORE calling model.
