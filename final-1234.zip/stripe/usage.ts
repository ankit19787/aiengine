
import { stripe } from "./stripe"

export async function chargeUsage(subscriptionItemId: string, tokens: number) {
  await stripe.subscriptionItems.createUsageRecord(
    subscriptionItemId,
    {
      quantity: tokens,
      timestamp: "now",
      action: "increment"
    }
  )
}
