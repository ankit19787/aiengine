
export default function Signup() {
  return (
    <form>
      <h2>Sign Up</h2>
      <input placeholder="Email" />
      <input placeholder="Password" type="password" />
      <button>Create Account</button>
    </form>
  )
}
