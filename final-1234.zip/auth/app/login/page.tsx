
export default function Login() {
  return (
    <form>
      <h2>Login</h2>
      <input placeholder="Email" />
      <input placeholder="Password" type="password" />
      <button>Login</button>
    </form>
  )
}
