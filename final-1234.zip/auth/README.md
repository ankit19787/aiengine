
Auth UI
- Email/password UI
- Connect to Auth.js / Clerk
- Workspace creation after signup
