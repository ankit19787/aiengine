
import * as vscode from "vscode"

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand("aiengine.ask", async () => {
      const editor = vscode.window.activeTextEditor
      if (!editor) return

      const selection = editor.document.getText(editor.selection)
      const question = await vscode.window.showInputBox({ prompt: "Ask AI Engine" })
      if (!question) return

      const panel = vscode.window.createWebviewPanel(
        "aiEngine",
        "AI Engine",
        vscode.ViewColumn.Beside,
        { enableScripts: true }
      )

      const res = await fetch("https://api.yourdomain.com/chat", {
        method: "POST",
        headers: {
          "Authorization": "Bearer YOUR_API_KEY",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: question + "\n" + selection })
      })

      const reader = res.body?.getReader()
      let output = ""

      while (true) {
        const { value, done } = await reader!.read()
        if (done) break
        output += new TextDecoder().decode(value)
        panel.webview.html = `<pre>${output}</pre>`
      }
    })
  )
}
