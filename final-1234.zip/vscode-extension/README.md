
VS Code Extension
- Streaming response
- Side panel UI
- Next: inline diff decorations
