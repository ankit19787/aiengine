Stripe Billing
- Create products: Free, Pro, Team
- Use metered billing by token usage
