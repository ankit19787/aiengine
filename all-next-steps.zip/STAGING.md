# Environments
- dev: localhost
- stage: stage.yourdomain.com
- prod: app.yourdomain.com

Use separate env vars per environment.
