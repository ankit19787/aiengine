#!/bin/bash
echo "Teams + invites placeholder"
