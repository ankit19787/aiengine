Branding
Name ideas:
- EngineAI
- CodeMind
- RepoAI
Tagline:
"An AI engine that understands your codebase."
