VS Code Extension Scaffold
- Command: Ask AI Engine
- Sends selection to API
