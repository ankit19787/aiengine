
import Stripe from "stripe"

export async function handleStripeWebhook(req, sig) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)
  return stripe.webhooks.constructEvent(
    req.body,
    sig,
    process.env.STRIPE_WEBHOOK_SECRET!
  )
}
