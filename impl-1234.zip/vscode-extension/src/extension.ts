
import * as vscode from "vscode"

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand("aiengine.ask", async () => {
      const editor = vscode.window.activeTextEditor
      if (!editor) return

      const selection = editor.document.getText(editor.selection)
      const input = await vscode.window.showInputBox({ prompt: "Ask AI Engine" })
      if (!input) return

      await fetch("https://api.yourdomain.com/chat", {
        method: "POST",
        headers: {
          "Authorization": "Bearer YOUR_API_KEY",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: input + "\n" + selection })
      })

      vscode.window.showInformationMessage("Sent to AI Engine")
    })
  )
}
