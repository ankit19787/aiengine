
Landing Page
- Next.js App Router
- Tailwind optional
- Deploy on Vercel
