
export default function Landing() {
  return (
    <main style={{ padding: 40 }}>
      <h1>AI that understands your entire codebase</h1>
      <p>Search, refactor, and reason across your repo with confidence.</p>
      <button>Start Free</button>
    </main>
  )
}
