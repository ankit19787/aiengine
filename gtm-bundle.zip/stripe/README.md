
Stripe Integration

Flow:
1. Workspace -> Stripe Customer
2. Usage -> Metered billing
3. Hard limits enforced in API

Env vars:
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
