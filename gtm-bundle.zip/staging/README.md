
Staging Setup

Create separate resources:
- DB
- Qdrant collection
- Stripe keys

Domains:
- api.stage.yourdomain.com
- stage.yourdomain.com
