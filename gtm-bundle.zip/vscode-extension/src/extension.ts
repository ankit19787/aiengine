
import * as vscode from "vscode"

export function activate(context: vscode.ExtensionContext) {
  const disposable = vscode.commands.registerCommand("aiengine.ask", async () => {
    const editor = vscode.window.activeTextEditor
    const text = editor?.document.getText(editor.selection)
    const question = await vscode.window.showInputBox({ prompt: "Ask AI Engine" })

    const res = await fetch("https://api.yourdomain.com/chat", {
      method: "POST",
      headers: {
        "Authorization": "Bearer YOUR_API_KEY",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: question + "\n" + text })
    })

    vscode.window.showInformationMessage("Sent to AI Engine")
  })

  context.subscriptions.push(disposable)
}
