
Landing Page

Tech:
- Next.js
- Tailwind

Sections:
- Hero
- How it works
- Pricing
- CTA
