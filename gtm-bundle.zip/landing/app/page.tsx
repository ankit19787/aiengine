
export default function Page() {
  return (
    <main>
      <h1>AI that understands your entire codebase</h1>
      <p>Chat with your repo. Refactor safely. Ship faster.</p>
      <button>Start Free</button>
    </main>
  )
}
