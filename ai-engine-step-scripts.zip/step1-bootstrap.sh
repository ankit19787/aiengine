#!/bin/bash
# STEP 1: Bootstrap AI Engine
chmod +x setup.sh
./setup.sh
