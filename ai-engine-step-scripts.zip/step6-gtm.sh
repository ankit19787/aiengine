#!/bin/bash
# STEP 6: GTM setup (Stripe, VSCode, Staging, Landing)
echo "Apply gtm-bundle.zip contents manually into repo"
