#!/bin/bash
# STEP 2: Add Claude, OpenAI, RAG, Tools, Diff
chmod +x add-ai-features.sh
./add-ai-features.sh
