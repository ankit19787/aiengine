#!/bin/bash
# STEP 3: Repo ingestion, planner, security
chmod +x add-core-platform.sh
./add-core-platform.sh
