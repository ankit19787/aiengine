#!/bin/bash
# STEP 5: Deploy API + Web
chmod +x deploy-api.sh
./deploy-api.sh
