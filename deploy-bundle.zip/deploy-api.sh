#!/bin/bash
set -e
echo "Deploying AI Engine API to Fly.io"
cd apps/api
fly launch --no-deploy || true
fly secrets set ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY OPENAI_API_KEY=$OPENAI_API_KEY DATABASE_URL=$DATABASE_URL QDRANT_URL=$QDRANT_URL
fly deploy
