# Deployment Bundle

1) API -> Fly.io
   - Copy Dockerfile and fly.toml into apps/api
   - Run ./deploy-api.sh

2) Web -> Vercel
   - Import apps/web
   - Set NEXT_PUBLIC_API_URL=https://<your-fly-app>.fly.dev
