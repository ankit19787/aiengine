export async function* agentLoop(state) {
  yield { type: "token", content: "Hello from AI Engine\n" }
  yield { type: "done", content: "" }
}