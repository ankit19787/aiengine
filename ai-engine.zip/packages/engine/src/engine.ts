import { agentLoop } from "../../agent/src/agent"

export async function* runEngine(input) {
  yield* agentLoop({ input, done: false })
}