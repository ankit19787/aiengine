export default function Page() {
  return <div>AI Engine Web UI</div>
}