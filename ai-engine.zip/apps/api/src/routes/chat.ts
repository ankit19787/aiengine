import { runEngine } from "@packages/engine/src/engine"

export async function chatRoute(app) {
  app.post("/", async (req, reply) => {
    const stream = runEngine({
      userMessage: req.body.message,
      sessionId: "local"
    })

    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache"
    })

    for await (const chunk of stream) {
      reply.raw.write(chunk.content)
    }
  })
}