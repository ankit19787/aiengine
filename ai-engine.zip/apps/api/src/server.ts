import Fastify from "fastify"
import { chatRoute } from "./routes/chat"

const app = Fastify()
app.register(chatRoute, { prefix: "/chat" })
app.listen({ port: 3001 })