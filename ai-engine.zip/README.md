# AI Engine

Local + Cloud AI Engine (Claude/Cursor-style)